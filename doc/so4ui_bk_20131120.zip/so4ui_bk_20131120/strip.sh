arm-none-linux-gnueabi-strip ./libhmui_event.so
