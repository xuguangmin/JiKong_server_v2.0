/*
 * luaevent.h
 *
 *  Created on: 2013��9��18��
 *      Author: flx
 */

#ifndef __LUAEVENT_H__
#define __LUAEVENT_H__

extern int lua_register_jikong_lib(lua_State *L);

#endif /* __LUAEVENT_H__ */
